let rx = 0;
let ry = 0;
let cam;
let pinSize = globeSize/100;
let state = 0;
let start;
let end;
let cm, c1, c2;
let sparkSpawn = 10;
let sparks = [];
let curves = [];
let sparkSpeed = 0.5;
let decay = 1;


class spark{
	constructor(x, y, z, dx, dy, dz){
		this.x = x;
		this.y = y;
        this.z = z;
		this.dx = dx;
		this.dy = dy;
        this.dz = dz;
		this.life = 40;
        this.speed = sparkSpeed;
	}
	movr(){
		this.x += this.speed * this.dx;
		this.y += this.speed * this.dy;
        this.z += this.speed * this.dz;
        this.speed/=1.5
		this.life -= decay*random(10);
	}
	drar(){
      push();
      translate(this.x, this.y, this.z);
      fill("red")
	  sphere(0.8);
      pop();
	}
}

function preload() {
  img = loadImage('earth_outline.jpeg');
	star_img = loadImage('night_sky1.png');
   font = loadFont('https://fonts.gstatic.com/s/inter/v3/UcCO3FwrK3iLTeHuS_fvQtMwCp50KnMw2boKoduKmMEVuGKYMZhrib2Bg-4.ttf')
}


function setup() {
  createCanvas(canvasSize, canvasSize, WEBGL);
  //debugMode()
  cam = this._renderer._curCamera;
  textFont(font)
}

function draw() {
  orbitControl();
	noStroke();
  background(0);
  texture(img);
	ambientLight("#CDDC39");
  pointLight(255, 0, 0, cam.eyeX, cam.eyeY, cam.eyeZ)
  sphere(globeSize);
	texture(star_img);
	sphere(starSize);
  if (sparks.length > 0) {
        moveSparks();
  }
  switch(state){
    case 0:
      strokeWeight(1.5);
      stroke("Red")
      line(0, 0, 0, cam.eyeX, cam.eyeY, cam.eyeZ);
      break;
    case 1:
      push();
      strokeWeight(1.5);
      stroke("Red")
      line(0, 0, 0, cam.eyeX, cam.eyeY, cam.eyeZ);
      translate(start.x, start.y, start.z);
      drawPin();
      pop();
      break;
    case 2:
      push();
      translate(start.x, start.y, start.z);
      drawPin();
      pop();
      push();
      translate(end.x, end.y, end.z);
      drawPin();
      pop();
      stroke("red")
      //curve(start.x, start.y, start.z, c1.x, c1.y, c1.z, c2.x, c2.y, c2.z, end.x, end.y, end.z);
      for (let i = 0; i < curves.length; i += 5){
        beginShape();
        curveVertex(curves[i].x, curves[i].y, curves[i].z);
        curveVertex(curves[i].x, curves[i].y, curves[i].z);

        curveVertex(curves[i+1].x, curves[i+1].y, curves[i+1].z);
        curveVertex(curves[i+2].x, curves[i+2].y, curves[i+2].z);
        curveVertex(curves[i+3].x, curves[i+3].y, curves[i+3].z);

        curveVertex(curves[i+4].x, curves[i+4].y, curves[i+4].z);
        curveVertex(curves[i+4].x, curves[i+4].y, curves[i+4].z);
        endShape();
        break;
      }
      
  }
    
}

function keyPressed(){
  if ((state == 0 || state == 1) && keyCode == ENTER){
    c = createVector(cam.eyeX, cam.eyeY, cam.eyeZ);
    c.normalize();
    if (state == 0) {
      start = createVector(c.x*globeSize, c.y*globeSize, c.z*globeSize);
    }
    else {
      end = createVector(c.x*globeSize, c.y*globeSize, c.z*globeSize)
      getCurves(start, end);
    }
    burstSparks(c.x*globeSize, c.y*globeSize, c.z*globeSize)
    state++;
  }
  
}

function moveSparks(){
  for (let i = 0; i < sparks.length; i++){
			sparks[i].movr();
			sparks[i].drar();
			if (sparks[i].life < 0){
				sparks.splice(i, 1)
		}
	}
}

function burstSparks(x, y, z){
  for (let i = 0; i < sparkSpawn; i++){
    let m = createVector(x, y, z);
    m.normalize();
    let tim = new spark(x, y, z, m.x+random(-5,5), m.y+random(-5,5), m.z+random(-5,5))
    sparks.push(tim)
  }
}



function getCurves(curveStart, curveEnd){
      let csmx = (end.x + start.x)/2
      let csmy = (end.y + start.y)/2
      let csmz = (end.z + start.z)/2
      csm = createVector(csmx, csmy, csmz)
      csm.normalize()
      csm.mult(globeSize);
      let cs1x = (start.x + csmx)/2
      let cs1y = (start.y + csmy)/2
      let cs1z = (start.z + csmz)/2
      cs1 = createVector(cs1x, cs1y, cs1z)
      cs1.normalize()
      cs1.mult(globeSize);
      let cs2x = (end.x + csmx)/2
      let cs2y = (end.y + csmy)/2
      let cs2z = (end.z + csmz)/2
      cs2 = createVector(cs2x, cs2y, cs2z)
      cs2.normalize()
      cs2.mult(globeSize);
      curves.push(curveStart)
      curves.push(cs1)
      curves.push(csm)
      curves.push(cs2)
      curves.push(curveEnd)
}



function drawPin(){
  normalMaterial();
  fill(255, 0, 0, 100)
  sphere(pinSize*(3/4));
  if (frameCount%30 > 10){
    fill(255, 0, 0, 60)
    sphere(pinSize);
  }
}

/*
function spherePos(x, y){
  r = globeSize;
}*/
